package com.crud.EmployeeMgtBackend.dao;
import com.crud.EmployeeMgtBackend.entities.Employee;
import org.springframework.data.jpa.repository.JpaRepository;


public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

    public Employee findByMobileNo(String mobileNo);

}
