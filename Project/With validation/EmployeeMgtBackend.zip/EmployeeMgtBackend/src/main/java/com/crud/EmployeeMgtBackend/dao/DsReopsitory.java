package com.crud.EmployeeMgtBackend.dao;

import com.crud.EmployeeMgtBackend.entities.DS;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DsReopsitory extends JpaRepository<DS, Integer> {
}
