package com.crud.EmployeeMgtBackend.dao;

import com.crud.EmployeeMgtBackend.entities.Address;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AddressRepository extends JpaRepository<Address, Long> {
}
