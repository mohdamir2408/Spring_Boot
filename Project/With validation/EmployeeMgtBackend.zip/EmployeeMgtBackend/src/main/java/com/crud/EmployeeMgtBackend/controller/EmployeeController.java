package com.crud.EmployeeMgtBackend.controller;

import com.crud.EmployeeMgtBackend.ValidatorInterface.EmployeeValidator;
import com.crud.EmployeeMgtBackend.dao.EmployeeRepository;
import com.crud.EmployeeMgtBackend.entities.Employee;
import com.crud.EmployeeMgtBackend.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class EmployeeController {
    @Autowired
    private EmployeeValidator  employeeValidator;
    @Autowired
    private EmployeeRepository employeeRepository;

    @InitBinder("Employee")
    public void initBinder(WebDataBinder binder) {

        binder.setValidator(employeeValidator);

    }

    // Get All Employee Rest Api
    @GetMapping("/employees")
    public ResponseEntity<List<Employee>> getAllEmployees()
    {
        return new ResponseEntity<List<Employee>>(employeeRepository.findAll(),HttpStatus.OK);
    }

     //Get Employee By id Rest Api
    @GetMapping("/employeeById")
    public ResponseEntity<Employee> getEmployeeByID(@RequestParam int id)
    {
        Employee employee = employeeRepository.findById(id).orElseThrow(
                ()-> new ResourceNotFoundException("Employee doesn't exist with id:"+id));
        return ResponseEntity.ok(employee);
    }

    //Create Employee Rest Api
    @PostMapping("/employees/save")
    //public Employee createEmployee(@RequestBody Employee employee)
    public ResponseEntity<?>createEmployee(@Valid @RequestBody Employee employee, Errors errors) {
    {
        //return employeeRepository.save(employee);



        if (errors.hasErrors()) {

            return new ResponseEntity<>(errors.getAllErrors(), HttpStatus.BAD_REQUEST);

        }

        return new ResponseEntity<>(employeeRepository.save(employee), HttpStatus.CREATED);

    }


    }

    //Delete Employee Rest Api
    @DeleteMapping("/employees/{id}")
    public ResponseEntity<Object> deleteEmployee(@PathVariable int id){
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

        employeeRepository.delete(employee);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }



    //Update Employee Rest Api
    @PutMapping("/updateEmployee")
    public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employeeDetails){
        Employee employee = null;
        employee=employeeRepository.findById(employeeDetails.getId()).get();
        if(employee==null) return new ResponseEntity<>(HttpStatus.OK);
        else {
            employee.setFirstName(employeeDetails.getFirstName());
            employee.setLastName(employeeDetails.getLastName());
            employee.setEmailId(employeeDetails.getEmailId());
            employee.setMobileNo(employeeDetails.getMobileNo());
            employee.setAddressList(employeeDetails.getAddressList());
            employee.setDs(employeeDetails.getDs());
            Employee updatedEmployee = employeeRepository.save(employee);
            return new ResponseEntity<Employee>(updatedEmployee,HttpStatus.OK);
        }
    }


}
