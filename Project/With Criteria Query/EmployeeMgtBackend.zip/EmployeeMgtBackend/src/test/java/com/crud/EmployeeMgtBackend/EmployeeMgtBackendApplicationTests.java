package com.crud.EmployeeMgtBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeMgtBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
