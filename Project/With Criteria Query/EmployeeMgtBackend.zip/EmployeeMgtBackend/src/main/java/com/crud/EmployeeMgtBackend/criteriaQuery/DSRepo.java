package com.crud.EmployeeMgtBackend.criteriaQuery;

public interface DSRepo {
}
