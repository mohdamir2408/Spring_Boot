package com.crud.EmployeeMgtBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeMgtBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeMgtBackendApplication.class, args);
	}

}
