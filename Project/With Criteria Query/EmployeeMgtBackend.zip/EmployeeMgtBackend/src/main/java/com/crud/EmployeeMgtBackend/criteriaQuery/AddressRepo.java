package com.crud.EmployeeMgtBackend.criteriaQuery;

public interface AddressRepo {
}
